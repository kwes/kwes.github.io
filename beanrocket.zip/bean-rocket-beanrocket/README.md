# bean rocket
this was originally a game i made back in 2021, since then it has had mutiple updates, however i choose this specific version as it is pretty neat
## info
smelly.js is the original code (IT SUCKS SO BAD!), index.js is basically the same code but simplified
## playing
